<?php
$name = "Diart";
$lastname= "Nika";
echo "Hello $name $lastname ". "<br>";

$pi= 3.14;
$r= 10;
$s= $pi * pow($r,2);
echo $s. "<br>";

$age = 15;

if($age >= 18){
    echo "Mundesh me votu". "<br>";
}else{
    echo "Nuk mundesh me votu". "<br>";
}

$day= 3;

switch($day){
    case 1:
         case 2: case 3:case 4: case 5:
             echo "It's a Weekday". "<br>" ;
             break;
             case 6: case 7:
               echo "It's Weekend". "<br>" ;
               break;
          default:
          echo "Invalid day". "<br>";
          break;
}

function shuma($n){
    return array_sum($n);
}

$n = array(1, 2, 4);
echo "Shuma: " . shuma($n);




?>