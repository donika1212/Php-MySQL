<?php

try{
    $pdo = new PDO ("mysql:host =localhost;dbname=test_db2", "root", "");

    $sql = "DROP TABLE products"; 

    $pdo ->exec($sql);

    echo "Table dropped succesfully";


}catch(PDOExeption $e){
    echo "Error creatin table:". $e->getMessage();
}



?>