<?php

try{
  $pdo = new PDO ("mysql:host =localhost;dbname=test_db2", "root", "");
  
   $sql = "ALTER TABLE products DROP  name VARCHAR(255)"; 

    $pdo ->exec($sql);

    echo "Column deleted succesfully";

}catch(PDOExeption $e){
    echo "Error creatin table:". $e->getMessage();
}

?>