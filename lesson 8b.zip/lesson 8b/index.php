<?php

try{
    $pdo = new PDO ("mysql:host =localhost;dbname=test_db2", "root", "");

    $sql = "ALTER TABLE products Add email VARCHAR(255)"; 

    $pdo ->exec($sql);

    echo "Column created succesfully";


}catch(PDOExeption $e){
    echo "Error creatin table:". $e->getMessage();
}



?>