<?php
$school = "Digital school";

echo "i love $school" . "<br>";

//Simple arithmetic's
$x = 120;
$y = 50;

echo $x + $y . "<br>";
echo $x - $y . "<br>";

echo $x / $y . "<br>";
echo $x * $y . "<br>";

echo $x % $y . "<br>";

//Concatenation

$a="digital";
$b="school";

$c=$a.$b;

echo $c . "<br>";

//String functions

$the_string = "digital school";

echo strlen($the_string) . "<br>";

echo str_word_count($the_string) . "<br>";

$programming = "Programming is not cool";
echo str_replace("not", "very",$programming) . "<br>";

$the_string="programming";
echo strrev($the_string) . "<br>";

//comditonals
$num = -1;

if($num < 0) {
    echo "$num is less than 0" . "<br>";
}
$age=15;
if(($age > 12) && ($age <20)){
    echo "you are a teenager" . "<br>";
}

if($age < 18){
    echo "you are under 18" . "<br>";
}else {
    echo "you are an adult";
}

if($num <0){
    echo "the value of $num is a negative number" . "<br>";
}elseif($num==0){
    echo "the vale of $num is 0";
}else {
    echo "the value of $num is a pozitive number";
}

$a = 1;
$b = 1;

if($a == $b){
    echo "yes";
} else {
    echo "no";
}
     







?>