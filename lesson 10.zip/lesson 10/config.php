<?php

$user="root";
$pass="";
$host="localhost";
$dbname="database1";

try {
    $conn= new PDO("mysql:host=$host;dbname=$dbname",$user,$pass);


}catch(Exeption $e) {
    echo "Error:" .$e->getMessage();
}












?>