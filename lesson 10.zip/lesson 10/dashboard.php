
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

<style>
    table,td,th{
    border:1px solid black;
    border-collapse:collapse;
    }
    td,th {
        padding:10px 20px;
    }
</style>
</head>
<body>
    
<?php
  include_once("config.php");
  $sql="SELECT * FROM user1";
  $getUsers = $conn->prepare($sql);
  $getUsers->execute();
  $users=$getUsers->fetchAll();
?>
  <br>
  <br>


<table>
    <thread>
    <th>ID<th>
    <th>Name<th>
    <th>Surname<th>
    <th>Email<th>
</thead>
<tbody>
    <?php

   foreach($users as $user1){
    ?>
    <tr>
        <td><?= $user1["id"]?></td>
        <td><?= $user1["name"]?></td>
        <td><?= $user1["surname"]?></td>
   </tr>
   
   <?php
   }
   ?>
</tbody>
</table>

<a href="add.php">Add user</a>







</body>
</html>