<?php

 echo "Digital School";

?>