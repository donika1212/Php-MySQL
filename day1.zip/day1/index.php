<?php

$school = "Digital School";


echo"I love digital $school" .  "<br>";

//Simple Arithmetic's
$x = 120;
$y= 50;

echo $x + $y . "<br>";
echo $x - $y  . "<br>";

echo $x / $y. "<br>";
echo$x * $y . "<br>";

echo $x % $y ;



//Concatenation

$a= "Digital";
$b= "School";

$c= $a.$b ;

echo "$c";  "<br>";


//String functions

$the_string = "digital Shool";

echo strlen($the_string) . "<br>";

echo str_word_count($the_string) . "<br>";

$programing = "programing is not cool";

echo str_replace("not","very", $programing) . "<br>";

$the_string="programing";

echo strrev($the_string)  . "<br>";

//Conditonals
$num = -1;

if($num < 0) {
    echo "$num is less than 0" . "<br>";

}

$age=15;
if(($age > 12)&&($age <20)) {
    echo "You are a teenager" . "<br>";
}

if ($age < 18){
    echo "you are under 18";
} else {
    echo "You are an adult";
}

if($num <0){
    echo "The value of $num is a negative number" . "<br>";    
} elseif($num==0){
    echo "The value of $num is 0";    
}else {
    echo "The value of $sum is a pozitive number" . "<br>";
}

$num1=1;
$num2=2;



if($num1 == $num2){
    echo "posotive"
}else{
    echo "negative"
}






?>