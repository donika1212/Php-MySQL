<?php

   //User defined functions

   function maximum($x,$y){
    if($x > $y){
        return $x;
    }else{
        return $y;
    }
   }

   $a=20;
   $b=30;

   $test = maximum($a,$b);
  echo "The max of $a and $b is $test". "<br>";

  function fully_divisible($n){
    if($n%2 ==0){
        return "$n is fully divisible by 2";
    
}else{
    return "$n is not fully divisible by 2";
}


  }
  
  //print_r(fully_divisible(4)). "<br>"

  //Variable Scope
  //global
  //local
  //static

  $x=5; //global

  function localVariable() {
    $x=5; //local
    $y = 10; //local
    echo $x . "<br>";
    echo $y . "<br>";
  }

  localVariable();

  //static

  function add1(){
    static $number=0;
    $number++;
    return $number;
  }

  echo add1();
  echo "<br>";
  echo add1();
  echo "<br>";
  echo add1();
 
  //Arrays

  $sport1= "Football";
  $sport2= "Basketball";
  $sport3= "Handball";
  $sport4= "Voleyball";

  //$sport = array("Football", "Basketball","Handball", "Voleyball");

  $sports = ["Football", "Basketball","Handball", "Voleyball"];

  echo "<br>";
  echo $sports[0];
  echo "<br>";
  echo $sports[2];
  echo "<br>";
  echo end($sports);
  echo "<br>";
  echo count($sports);
  echo "<br>";

  $len = count($sports);
  for($i=0; $i < $len; $i++) {
    echo $sports [$i] , "\n";
    }
    echo "<br>";

    array_push($sports,"Golf");

    var_dump($sports);
    echo "<br>";
  array_pop($sports);
  var_dump($sports);
  echo "<br>";

  array_unshift($sports, "Tennis");
  var_dump($sports);
  echo "<br>";

  array_shift($sports);
  var_dump($sports);
  echo "<br>";

  $output = array_slice($sports, 2);
  var_dump($sports);
  echo "<br>";




  $sports = ["Football", "Basketball","Handball", "Voleyball"];

  $output = array_slice($sports,-2,1);
  var_dump($output);
  echo "<br>";

  //array_sum

  $values = [12, 24, 30, 55];

  $sum = array_sum($values);
  var_dump($sum);
  echo "<br>";

  $weektemp = [20,15,24,30,17,18,21];

  $average = array_sum($weektemp)/8;
  echo($average);
  echo "<br>";

  















?>