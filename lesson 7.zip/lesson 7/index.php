<?php

$host = "localhost";
$user = "root";
$pass = "";

try{

    $con = new PDO ("mysql:host =$host", $user, $pass);

    $sql = "CREATE DATABASE database2";

   $con ->exec($sql);
   echo "Database created";

    echo "Connected";


}catch(Exeption $e){
    echo "Not connected";
}