
const body = document.querySelector("body"),
      nav = document.querySelector("nav"),
      modeToggle = document.querySelector(".dark-light"),
      searchToggle = document.querySelector(".searchToggle"),
      sidebarOpen = document.querySelector(".sidebarOpen"),
      sidebarClose = document.querySelector(".siderbarClose");


let getMode = localStorage.getItem("mode");
if (getMode && getMode === "dark-mode") {
    body.classList.add("dark-mode");
} else {
    body.classList.add("light-mode");
}


modeToggle.addEventListener("click", () => {
    modeToggle.classList.toggle("active");
    body.classList.toggle("dark-mode");
    body.classList.toggle("light-mode");
    nav.classList.toggle("dark-mode");
    nav.classList.toggle("light-mode");

    if (body.classList.contains("dark-mode")) {
        document.documentElement.style.setProperty('--nav-color', '#333'); 
    } else {
        document.documentElement.style.setProperty('--nav-color', '#aba946'); 
    }

    
    localStorage.setItem("mode", body.classList.contains("dark-mode") ? "dark-mode" : "light-mode");
});


searchToggle.addEventListener("click", () => {
    searchToggle.classList.toggle("active");
   
});

sidebarOpen.addEventListener("click", () => {
    nav.classList.add("active");
});

body.addEventListener("click", (e) => {
    let clickedElm = e.target;
    if (!clickedElm.classList.contains("sidebarOpen") && !clickedElm.classList.contains("menu")) {
        nav.classList.remove("active");
    }
});