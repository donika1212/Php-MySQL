<form id="contact-form" class="form-horizontal" role="form" method="POST" action="contact.php">
	<?php
// Define variables and initialize with empty values
$name = $email = $message = "";
$name_err = $email_err = $message_err = "";

// Processing form when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Validate name
    if (empty(trim($_POST["name"]))) {
        $name_err = "Please enter your name.";
    } else {
        $name = trim($_POST["name"]);
    }

    // Validate email
    if (empty(trim($_POST["email"]))) {
        $email_err = "Please enter your email.";
    } elseif (!filter_var(trim($_POST["email"]), FILTER_VALIDATE_EMAIL)) {
        $email_err = "Invalid email format.";
    } else {
        $email = trim($_POST["email"]);
    }

    // Validate message
    if (empty(trim($_POST["message"]))) {
        $message_err = "Please enter a message.";
    } else {
        $message = trim($_POST["message"]);
    }

    // If there are no errors, send the email
    if (empty($name_err) && empty($email_err) && empty($message_err)) {
        
        // Set the recipient email address
        $to = "verona.idrizi7@gmail.com"; // Change to your email address
        
        // Set the subject
        $subject = "New Contact Form Submission from $name";
        
        // Create the email content
        $email_content = "Name: $name\n";
        $email_content .= "Email: $email\n\n";
        $email_content .= "Message:\n$message\n";
        
        // Set the headers
        $headers = "From: $email\r\n";
        $headers .= "Reply-To: $email\r\n";
        
        // Send the email
        if (mail($to, $subject, $email_content, $headers)) {
            echo "<p>Your message has been sent successfully!</p>";
        } else {
            echo "<p>Oops! Something went wrong, and we couldn't send your message. Please try again later.</p>";
        }

    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ahmet Gashi - Contact</title>
    <link rel="stylesheet" href="contact.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
</head>
<body class="light-mode">
    <nav>
        <div class="nav-bar">
            <i class='bx bx-menu sidebarOpen'></i>
            <span class="logo navLogo"><a href="#">Ahmet Gashi</a></span>
            <div class="menu">
                <div class="logo-toggle">
                    <span class="logo"><a href="#">Ahmet Gashi</a></span>
                    <i class='bx bx-x siderbarClose'></i>
                </div>
                <ul class="nav-links">
                    <li><a href="index.html">Home</a></li>
                    <li><a href="about.html">About</a></li>
                    <li><a href="arritjettona.html">Arritjet tona</a></li>
                    <li><a href="contact.php">Contact</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <section id="contact">
        <h1 class="section-header">Contact</h1>
        <div class="contact-wrapper">
            <form id="contact-form" class="form-horizontal" role="form" method="POST" action="contact.php">
                <div class="form-group">
                    <div class="col-sm-12">
                        <input type="text" class="form-control" id="name" placeholder="NAME" name="name" value="<?php echo $name; ?>" required>
                        <span class="error"><?php echo $name_err; ?></span>
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-sm-12">
                        <input type="email" class="form-control" id="email" placeholder="EMAIL" name="email" value="<?php echo $email; ?>" required>
                        <span class="error"><?php echo $email_err; ?></span>
                    </div>
                </div>

                <textarea class="form-control" rows="10" placeholder="MESSAGE" name="message" required><?php echo $message; ?></textarea>
                <span class="error"><?php echo $message_err; ?></span>
                
                <button class="btn btn-primary send-button" id="submit" type="submit" value="SEND">
                    <div class="alt-send-button">
                        <i class="fa fa-paper-plane"></i><span class="send-text">SEND</span>
                    </div>
                </button>
            </form>
        </div>
    </section>

    <script src="contact.js"></script>
</body>
</html>