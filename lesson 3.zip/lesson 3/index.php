<?php

//switch

 $age=15;

 switch($age){

    case($age >=0 && $age <18):
      echo "You are a minor (0-18 years old)" . "<br>";
      break;
       case($age >=18 && $age <=25):
       echo "You are an adult". "<br>" ;
       break;
       case($age >25):
        echo "You are an adult". "<br>";
        break;
        default:
        echo "Invalid age". "<br>";
        break;
 }

 $day = "Tuesday";
 
 switch($day){

  case "Monday":
    echo "It's Monday". "<br>";
    break;
     case "Tuesday":
     echo "It's Tuesday". "<br>" ;
     break;
     case "Wednesday":
      echo "It's Wednesday". "<br>" ;
      break;
      case "Thursday":
        echo "It's Thursday". "<br>" ;
        break;
        case "Friday":
         echo "It's Friday". "<br>" ;
         break;
         case "Saturday":
          echo "It's Saturday". "<br>" ;
          break;
          case "Sunday":
           echo "It's Sunday". "<br>" ;
           break;
      default:
      echo "Invalid day". "<br>";
      break;
}

//Loop(Unazat)
 
  $x =1 ;

  while( $x <= 5) {
    echo "The number is: $x". "<br>";

    $x++;

  }

   $y =1;

   do {
   echo "The number is: $y. ". "<br>";
   $y++;
   }while( $y <=6);

   for($x=0; $x < 10; $x++){
    echo "Shkolla Digjitale" . "<br>"; 
   }

   $cars = array("BMW","VW","Audi","RIMAC NIVERA");

   foreach($cars as $value) {

   echo "$value". "<br>";
  }

   $age = array("John"  => "18", "Michael"  => "23","Joe"  => "10");
   
   foreach($age as $key => $value)  {

    echo "$key = $value". "<br>";
   }

  //Built-in Functions

  //phpinfo();

  $y="Hello" . "<br>";

  print_r($y);

  $x=2;
  echo gettype($x) . "<br>";

  $x=2.3;
  echo gettype($x) . "<br>";

  $x="Shkolla";
  echo gettype($x) . "<br>";

  function displayPhpVersion (){

    echo "This is Php" . phpversion() . "<br>";

  }

  displayPhpVersion();

  

?>